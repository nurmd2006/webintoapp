# WebIntoApp - Android WebView Application

A complete Android application template for wrapping web content in a native Android app.

## 📋 Features

- 🌐 WebView Integration
- 📱 Responsive Design
- ⚡ Fast Loading
- 🔧 Easy Configuration
- 🚀 GitHub Actions CI/CD
- 📦 Ready to Deploy

## 🚀 Getting Started

### Prerequisites

- Android Studio (Latest Version)
- JDK 11 or higher
- Android SDK 21+ (minSdk)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/WebIntoApp.git
cd WebIntoApp
```

2. Open in Android Studio:
   - File → Open → Select project folder

3. Build the project:
```bash
./gradlew build
```

4. Run the app:
```bash
./gradlew installDebug
```

## 📁 Project Structure

```
WebIntoApp/
├── .github/workflows/
│   └── android-build.yml
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/example/webintoapp/
│   │   │   │   └── MainActivity.kt
│   │   │   ├── res/
│   │   │   │   ├── layout/
│   │   │   │   ├── values/
│   │   │   │   └── drawable/
│   │   │   ├── assets/
│   │   │   │   ├── index.html
│   │   │   │   ├── css/
│   │   │   │   ├── js/
│   │   │   │   └── images/
│   │   │   └── AndroidManifest.xml
│   │   ├── test/
│   │   └── androidTest/
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── README.md
```

## 🛠️ Configuration

### Using Local HTML

To use local HTML from the assets folder:

```kotlin
webView.loadUrl("file:///android_asset/index.html")
```

### Using Remote URL

To load a remote website:

```kotlin
webView.loadUrl("https://yourwebsite.com")
```

## 🔨 Building

### Debug Build

```bash
./gradlew assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`

### Release Build

```bash
./gradlew assembleRelease
```

Output: `app/build/outputs/apk/release/app-release.apk`

## 🚀 GitHub Actions CI/CD

The project includes an automated CI/CD workflow that:

- ✅ Builds on every push
- ✅ Runs unit tests
- ✅ Generates APK and AAB files
- ✅ Uploads artifacts

Workflow file: `.github/workflows/android-build.yml`

## 📦 Dependencies

- AndroidX AppCompat
- AndroidX ConstraintLayout
- Google Material Components
- Kotlin Standard Library

## 🔐 Permissions

The app requires these permissions (in `AndroidManifest.xml`):

- `android.permission.INTERNET` - For web access
- `android.permission.ACCESS_NETWORK_STATE` - For network status

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License.

## 👨‍💻 Author

Your Name - [@yourusername](https://github.com/yourusername)

## 📞 Support

For issues and questions, please create an issue on GitHub.

---

**Happy Coding! 🎉**